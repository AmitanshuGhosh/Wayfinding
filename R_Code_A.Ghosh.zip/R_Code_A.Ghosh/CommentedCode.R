# Codes and comments
#a is participant details in zip
#b is quetionnaire results in zip
View(a) #a contains the participant details along with the mean sum of their immersion scores
View(b) #b contains the results to the immersion scores
View(Map) #data about participants who played the maze with the map
View(NoMap) #data about participants who played the maze without the map

#paired samples t-tests
#conducting t tests on time taken in Map and NoMap
library(dplyr) #for the statistical tests
#need to extract time and convert it from mm:ss to ss
MapTime = as.data.frame(Map[,3])
View(MapTime)
NoMapTime = as.data.frame(NoMap[,3])
View(NoMapTime)
#now to convert the time to ss
library(lubridate) #lib to help with the process
#library wasnt woirking so i did it manually
#to convert mm:ss to seconds
library(readxl)
Time_Data <- read_excel("C:/Users/amitn/OneDrive/Desktop/Time Data.xlsx")
View(Time_Data) #the data set with times in ss format
#now we run a normality test because its a pre requisite for the t test
#values need to be >0.05
shapiro.test(Time_Data$MapTime) #p = 0.6
shapiro.test(Time_Data$NoMapTime) # p = 0.5
#after confirming normal distribution we now check for variance
#another modified dataset to simplify the var tests
library(readxl)
VarTest <- read_excel("C:/Users/amitn/OneDrive/Desktop/VarTest.xlsx")
View(VarTest)

#var test
var.test(time ~ group, data = VarTest) #p - 0.34 
#since p > 0.05 there is no significant diff in variance


#now we can do the unpaired two sample t test between time taken and game type.
t.test(time ~ group, data = VarTest, var.equal= TRUE) #p = 0.95 not significant
#can conclude there is no significant difference in time taken between both 
#variations of the mazes


#now we test the significance levels for immersion levels between the two mazes
library(readxl)
immersion_mazes <- read_excel("C:/Users/amitn/OneDrive/Desktop/immersion mazes.xlsx")
View(immersion_mazes) #this data set contains the immersion scores (out of 80) over both mazes
#two variations one with participants with map and one without map
library(readxl)
immersion_map <- read_excel("C:/Users/amitn/OneDrive/Desktop/immersion map.xlsx")
View(immersion_map)
library(readxl)
immersion_no_map <- read_excel("C:/Users/amitn/OneDrive/Desktop/immersion no map.xlsx")
View(immersion_no_map)
#normality test
shapiro.test(immersion_no_map$`immersion score`) # p = 0.72
shapiro.test(immersion_map$`immersion score`) #p = 0.72
#var test
var.test(immersion_score ~ group, data = immersion_mazes) #p = 0.79
#now we can proceed with the t test
t.test(immersion_score ~ group, data = immersion_mazes, var.equal = TRUE) #p = 0.11
#we can conclude that there is no significant relationship between the type of maze
#and immersion levels
install.packages("ggpubr") #pretty graphs
library(ggpubr)
#box plot of immersion score vs maze type
ggboxplot(immersion_mazes, x = "group", y = "immersion_score", color = "group", palette = c("#00AFBB", "#E7B800"), ylab = "Immersion Levels (out of 90)", xlab = "Groups")
#box plot of time taken vs maze type
ggboxplot(VarTest, x = "group", y = "time", color = "group", palette = c("#00AFBB", "#E7B800"),ylab = "Time", xlab = "Groups")

#testing nav strats by measuring secrets encountered (more secrets == more time spent exploring)
library(readxl)
secrets_mazes <- read_excel("C:/Users/amitn/OneDrive/Desktop/secrets mazes.xlsx")
View(secrets_mazes) #number of secrets and both mazes
library(readxl)
secrets_map <- read_excel("C:/Users/amitn/OneDrive/Desktop/secrets_map.xlsx")
View(secrets_map) #number of secrets with map
library(readxl)
secrets_no_map <- read_excel("C:/Users/amitn/OneDrive/Desktop/secrets_no_map.xlsx")
View(secrets_no_map) #number of secrets no map

#normality test
shapiro.test(secrets_map$secrets) #p = 1.837e -05
shapiro.test(secrets_no_map$secrets) #p = 0.05
#cannot assume normality

#means of time taken per maze
#maze with map
mean(Time_Data$MapTime) #avg = 42.7
#maze with no map
x = c(12,57,36,32,15,37,34,47,94,74,27,54) #manually typed in time taken because no map had a N/A value in the dataset
mean(x) #avg = 43.25

mean(a$age) #mean participant age